import os
import re
import sys
import logging
import subprocess
import threading
import shutil
import requests
import concurrent.futures
import urllib3
from typing import Any, Dict, Tuple
from flask import Flask, request, render_template, jsonify
from mutagen.easyid3 import EasyID3
from mutagen.id3 import ID3, APIC
from mutagen.mp3 import MP3
import webbrowser
from yt_dlp import YoutubeDL
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials

# Disable insecure request warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

app = Flask(__name__)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

download_status = {"status": "idle", "message": "No download in progress", "progress": 0}

def sanitize_filename(filename: str) -> str:
    return re.sub(r'[\\/*?:"<>|]', "", filename)

class DownloadManager:
    stop_flag: bool = False

    @staticmethod
    def reset_stop() -> None:
        DownloadManager.stop_flag = False

    @staticmethod
    def set_stop() -> None:
        DownloadManager.stop_flag = True

    @staticmethod
    def is_valid_youtube_url(url: str) -> bool:
        pattern = r'(https?://)?(www\.)?(youtube\.com/watch\?v=|youtu\.be/)'
        return bool(re.search(pattern, url))

    @staticmethod
    def _download_progress_hook(d: Dict[str, Any]) -> None:
        if DownloadManager.stop_flag:
            raise Exception("Download stopped by user.")
        if d.get("status") == "downloading":
            percent = d.get("_percent_str", "").strip()
            speed = d.get("_speed_str", "N/A")
            eta = d.get("_eta_str", "N/A")
            logging.info(f"Downloading: {percent} at {speed} | ETA: {eta}")

    @staticmethod
    def clean_track_info(original_title: str, uploader: str) -> Tuple[str, str]:
        pattern = r"^(?P<artist>.+?)\s*-\s*(?P<title>.+)$"
        m = re.match(pattern, original_title)
        if m:
            artist = m.group("artist").strip()
            title = m.group("title").strip()
        else:
            title = original_title.strip()
            artist = uploader.strip() if uploader else "Unknown Artist"
        title = re.sub(r"\s*[\[\(].*?[\]\)]$", "", title).strip()
        return title, artist

    @staticmethod
    def download_youtube(query: str, output_path: str, is_audio: bool = True, quality: str = None, metadata: dict = None, max_retries: int = 3) -> str:
        try:
            if DownloadManager.stop_flag:
                raise Exception("Download stopped before start.")
            quality_setting = quality or "1080"
            format_str = ("bestaudio/best" if is_audio 
                          else f'bestvideo[ext=mp4][height<={quality_setting}]+bestaudio[ext=m4a]/best[ext=mp4]')
            
            outtmpl = "%(title)s.%(ext)s" if not metadata else f"{sanitize_filename(metadata['artist'])} - {sanitize_filename(metadata['name'])}.%(ext)s"
            ydl_opts = {
                "outtmpl": os.path.join(output_path, outtmpl),
                "default_search": "ytsearch",
                "format": format_str,
                "quiet": True,
                "progress_hooks": [DownloadManager._download_progress_hook],
                "continue": True,
                "noplaylist": True,
                "ignoreerrors": False,
            }
            if is_audio:
                ydl_opts["postprocessors"] = [{
                    "key": "FFmpegExtractAudio",
                    "preferredcodec": "mp3",
                    "preferredquality": "192",
                }]

            retry_count = 0
            while retry_count < max_retries:
                try:
                    with YoutubeDL(ydl_opts) as ydl:
                        info = ydl.extract_info(query, download=False)
                        if not info:
                            raise Exception("No video found for query.")
                        
                        if info.get("age_limit", 0) > 0 or "Sign in to confirm your age" in str(info.get("reason", "")):
                            logging.warning(f"Age-restricted video skipped: {info.get('title', query)}")
                            retry_count += 1
                            query += f" alternative official audio -inurl:(lyrics topic)"
                            continue

                        if not metadata:
                            cleaned_title, cleaned_artist = DownloadManager.clean_track_info(info.get("title", ""), info.get("uploader", ""))
                            metadata = {
                                "name": cleaned_title,
                                "artist": cleaned_artist,
                                "album": info.get("album", ""),
                                "cover_url": info.get("thumbnail")
                            }
                        expected_filename = ydl.prepare_filename(info)
                        if is_audio:
                            base, _ = os.path.splitext(expected_filename)
                            expected_filename = f"{base}.mp3"
                        if os.path.exists(expected_filename):
                            logging.info(f"File exists, skipping: {expected_filename}")
                        else:
                            ydl.download([info["webpage_url"]])
                        DownloadManager.update_mp3_metadata(expected_filename, metadata)
                        return expected_filename
                except Exception as e:
                    if "Sign in to confirm your age" in str(e) or "age" in str(e).lower():
                        logging.warning(f"Retry {retry_count + 1}/{max_retries} due to age restriction: {str(e)}")
                        retry_count += 1
                        query += f" alternative official audio -inurl:(lyrics topic)"
                        continue
                    else:
                        logging.error(f"YouTube download failed: {str(e)}")
                        raise
            logging.error(f"Failed to find non-age-restricted video after {max_retries} retries for query: {query}")
            raise Exception("Could not find a downloadable non-age-restricted video.")
        except Exception as e:
            logging.error(f"YouTube download failed: {str(e)}")
            raise

    @staticmethod
    def download_soundcloud(url: str, output_path: str) -> str:
        try:
            ydl_opts = {
                "format": "bestaudio/best",
                "outtmpl": os.path.join(output_path, "%(uploader)s - %(title)s.%(ext)s"),
                "postprocessors": [{
                    "key": "FFmpegExtractAudio",
                    "preferredcodec": "mp3",
                    "preferredquality": "320",
                }],
                "quiet": True,
                "progress_hooks": [DownloadManager._download_progress_hook],
                "continue": True
            }
            with YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                cleaned_title, cleaned_artist = DownloadManager.clean_track_info(info.get("title", ""), info.get("uploader", ""))
                metadata = {
                    "name": cleaned_title,
                    "artist": cleaned_artist,
                    "album": "",
                    "cover_url": info.get("thumbnail")
                }
                expected_filename = ydl.prepare_filename(info)
                base, _ = os.path.splitext(expected_filename)
                expected_filename = f"{base}.mp3"
                if os.path.exists(expected_filename):
                    logging.info(f"File exists, skipping: {expected_filename}")
                else:
                    ydl.download([url])
                DownloadManager.update_mp3_metadata(expected_filename, metadata)
                return expected_filename
        except Exception as e:
            logging.error(f"SoundCloud download failed: {str(e)}")
            raise

    @staticmethod
    def initialize_spotify() -> spotipy.Spotify:
        try:
            auth_manager = SpotifyClientCredentials(
                client_id=os.getenv("SPOTIPY_CLIENT_ID", "62c275d1bc1d44ac83c311056b42d55a"),
                client_secret=os.getenv("SPOTIPY_CLIENT_SECRET", "1a259f3ab52b42cfa5229abaeba31fd3")
            )
            return spotipy.Spotify(auth_manager=auth_manager)
        except Exception as e:
            logging.error(f"Spotify initialization failed: {str(e)}")
            return None

    @staticmethod
    def get_spotify_tracks(sp_client: spotipy.Spotify, url: str):
        try:
            if "playlist" in url:
                playlist_id = url.split("/")[-1].split("?")[0]
                tracks = []
                offset = 0
                while True:
                    results = sp_client.playlist_tracks(playlist_id, offset=offset)
                    items = results.get("items", [])
                    if not items:
                        break
                    for item in items:
                        if track := item.get("track"):
                            tracks.append({
                                "name": track["name"],
                                "artist": track["artists"][0]["name"],
                                "album": track["album"]["name"],
                                "cover_url": track["album"]["images"][0]["url"] if track["album"].get("images") else None
                            })
                    if not results.get("next"):
                        break
                    offset += len(items)
                return tracks
            elif "track" in url:
                track_id = url.split("/")[-1].split("?")[0]
                track = sp_client.track(track_id)
                return [{
                    "name": track["name"],
                    "artist": track["artists"][0]["name"],
                    "album": track["album"]["name"],
                    "cover_url": track["album"]["images"][0]["url"] if track["album"].get("images") else None
                }]
            return None
        except Exception as e:
            logging.error(f"Spotify track retrieval failed: {str(e)}")
            return None

    @staticmethod
    def get_soundcloud_tracks(url: str):
        try:
            ydl_opts = {"extract_flat": True, "quiet": True}
            with YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                tracks = []
                if "entries" in info:
                    for entry in info["entries"]:
                        tracks.append({
                            "name": entry.get("title", ""),
                            "artist": entry.get("uploader", ""),
                            "album": "",
                            "cover_url": entry.get("thumbnail"),
                            "url": entry.get("url", url)
                        })
                else:
                    tracks.append({
                        "name": info.get("title", ""),
                        "artist": info.get("uploader", ""),
                        "album": "",
                        "cover_url": info.get("thumbnail"),
                        "url": url
                    })
                return tracks
        except Exception as e:
            logging.error(f"SoundCloud track retrieval failed: {str(e)}")
            return None

    @staticmethod
    def get_youtube_tracks(url: str):
        try:
            ydl_opts = {"extract_flat": True, "quiet": True}
            with YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                tracks = []
                if "entries" in info:
                    for entry in info["entries"]:
                        tracks.append({
                            "name": entry.get("title", ""),
                            "artist": entry.get("uploader", ""),
                            "album": "",
                            "cover_url": entry.get("thumbnail")
                        })
                else:
                    tracks.append({
                        "name": info.get("title", ""),
                        "artist": info.get("uploader", ""),
                        "album": "",
                        "cover_url": info.get("thumbnail")
                    })
                return tracks
        except Exception as e:
            logging.error(f"YouTube track retrieval failed: {str(e)}")
            return None

    @staticmethod
    def update_mp3_metadata(file_path: str, metadata: dict) -> None:
        try:
            if not os.path.exists(file_path):
                logging.error(f"File not found for metadata update: {file_path}")
                return
            
            try:
                audio = EasyID3(file_path)
            except Exception:
                audio = MP3(file_path, ID3=ID3)
                audio.add_tags()
            
            audio["title"] = metadata.get("name", "Unknown Title")
            audio["artist"] = metadata.get("artist", "Unknown Artist")
            audio["album"] = metadata.get("album", "Unknown Album")
            audio.save()

            cover_url = metadata.get("cover_url")
            if cover_url:
                try:
                    headers = {"User-Agent": "Mozilla/5.0"}
                    r = requests.get(cover_url, headers=headers, timeout=10, stream=True, verify=False)
                    r.raise_for_status()
                    cover_data = r.content
                    id3 = ID3(file_path)
                    id3.delall("APIC")
                    id3.add(APIC(encoding=3, mime="image/jpeg", type=3, desc="Cover", data=cover_data))
                    id3.save(file_path, v2_version=3)
                    logging.info(f"Updated metadata with cover art for {file_path}")
                except Exception as cover_err:
                    logging.error(f"Cover art download failed: {str(cover_err)}")
        except Exception as e:
            logging.error(f"Failed to update metadata for {file_path}: {str(e)}")

def download_spotify_track(track: dict, output_path: str) -> None:
    if DownloadManager.stop_flag:
        raise Exception("Download stopped by user.")
    query = f"{track['artist']} {track['name']} official audio site:youtube.com -inurl:(lyrics topic)"
    try:
        filename = DownloadManager.download_youtube(query, output_path, is_audio=True, metadata=track, max_retries=3)
        if filename:
            DownloadManager.update_mp3_metadata(filename, track)
    except Exception as e:
        logging.error(f"Failed to download Spotify track '{track['name']}' by {track['artist']}: {str(e)}")
        raise

def download_soundcloud_track(track: dict, output_path: str) -> None:
    if DownloadManager.stop_flag:
        raise Exception("Download stopped by user.")
    DownloadManager.download_soundcloud(track["url"], output_path)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/download", methods=["POST"])
def download():
    global download_status
    service = request.form.get("service")
    url = request.form.get("url")
    output_path = request.form.get("output_path")

    if not service or not url:
        return jsonify({"status": "error", "message": "Service and URL are required"}), 400

    url = url.strip()
    output_path = output_path.strip() if output_path else os.getcwd()
    if os.path.splitext(output_path)[1]:
        output_path = os.path.dirname(output_path)
    output_path = os.path.abspath(output_path)
    if not os.path.exists(output_path):
        os.makedirs(output_path, exist_ok=True)

    quality = request.form.get("quality", "1080") if service == "youtube" else None
    is_audio = request.form.get("is_audio") == "on" if service == "youtube" else True

    DownloadManager.reset_stop()
    download_status = {"status": "running", "message": f"{service.capitalize()} download started", "progress": 0}

    def run_download():
        global download_status
        try:
            if service == "youtube":
                if not DownloadManager.is_valid_youtube_url(url):
                    download_status = {"status": "error", "message": "Invalid YouTube URL", "progress": 0}
                    return
                DownloadManager.download_youtube(url, output_path, is_audio, quality)
                download_status = {"status": "idle", "message": "YouTube download completed", "progress": 100}
            elif service == "spotify":
                if not url.startswith("https://open.spotify.com/"):
                    download_status = {"status": "error", "message": "Invalid Spotify URL", "progress": 0}
                    return
                sp_client = DownloadManager.initialize_spotify()
                if not sp_client:
                    download_status = {"status": "error", "message": "Spotify initialization failed", "progress": 0}
                    return
                tracks = DownloadManager.get_spotify_tracks(sp_client, url)
                if not tracks:
                    download_status = {"status": "error", "message": "No tracks found", "progress": 0}
                    return
                total = len(tracks)
                completed = 0
                with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
                    future_to_track = {
                        executor.submit(download_spotify_track, track, output_path): track for track in tracks
                    }
                    for future in concurrent.futures.as_completed(future_to_track):
                        try:
                            future.result()
                        except Exception as e:
                            logging.error(f"Error downloading a Spotify track: {str(e)}")
                        completed += 1
                        progress = int((completed / total) * 100)
                        download_status = {"status": "running", "message": f"Downloaded {completed}/{total} tracks", "progress": progress}
                download_status = {"status": "idle", "message": "Spotify download completed", "progress": 100}
            elif service == "soundcloud":
                if not url.startswith("https://soundcloud.com/"):
                    download_status = {"status": "error", "message": "Invalid SoundCloud URL", "progress": 0}
                    return
                tracks = DownloadManager.get_soundcloud_tracks(url)
                if not tracks:
                    download_status = {"status": "error", "message": "No tracks found", "progress": 0}
                    return
                total = len(tracks)
                completed = 0
                with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
                    future_to_track = {
                        executor.submit(download_soundcloud_track, track, output_path): track for track in tracks
                    }
                    for future in concurrent.futures.as_completed(future_to_track):
                        try:
                            future.result()
                        except Exception as e:
                            logging.error(f"Error downloading a SoundCloud track: {str(e)}")
                        completed += 1
                        progress = int((completed / total) * 100)
                        download_status = {"status": "running", "message": f"Downloaded {completed}/{total} tracks", "progress": progress}
                download_status = {"status": "idle", "message": "SoundCloud download completed", "progress": 100}
            else:
                download_status = {"status": "error", "message": "Unsupported service", "progress": 0}
        except Exception as e:
            logging.error(f"{service.capitalize()} download failed: {str(e)}")
            download_status = {"status": "error", "message": str(e), "progress": 0}

    threading.Thread(target=run_download, daemon=True).start()
    return jsonify({"status": "started", "message": f"{service.capitalize()} download started", "progress": 0, "fragments": 10})

@app.route("/stop", methods=["POST"])
def stop_download():
    DownloadManager.set_stop()
    global download_status
    download_status = {"status": "stopped", "message": "Download stopped", "progress": download_status.get("progress", 0)}
    return jsonify(download_status)

@app.route("/preview", methods=["POST"])
def preview():
    service = request.form.get("service")
    url = request.form.get("url")
    if not service or not url:
        return jsonify({"status": "error", "message": "Service and URL are required"}), 400
    url = url.strip()

    if service == "youtube":
        if not DownloadManager.is_valid_youtube_url(url):
            return jsonify({"status": "error", "message": "Invalid YouTube URL"}), 400
        tracks = DownloadManager.get_youtube_tracks(url)
    elif service == "spotify":
        if not url.startswith("https://open.spotify.com/"):
            return jsonify({"status": "error", "message": "Invalid Spotify URL"}), 400
        sp_client = DownloadManager.initialize_spotify()
        if not sp_client:
            return jsonify({"status": "error", "message": "Spotify initialization failed"}), 500
        tracks = DownloadManager.get_spotify_tracks(sp_client, url)
    elif service == "soundcloud":
        if not url.startswith("https://soundcloud.com/"):
            return jsonify({"status": "error", "message": "Invalid SoundCloud URL"}), 400
        tracks = DownloadManager.get_soundcloud_tracks(url)
    else:
        return jsonify({"status": "error", "message": "Unsupported service"}), 400

    if not tracks:
        return jsonify({"status": "error", "message": "No tracks found"}), 404
    track_list = [{"name": t["name"], "artist": t["artist"], "album": t["album"], "cover_url": t["cover_url"]} for t in tracks]
    return jsonify({"status": "success", "tracks": track_list})

@app.route("/status", methods=["GET"])
def status():
    return jsonify(download_status)

def launch_app():
    """Launch the Flask application."""
    port = 5000
    url = f"http://localhost:{port}"
    if os.environ.get("WERKZEUG_RUN_MAIN") != "true":  # Only open browser on first run
        logging.info(f"Opening browser at {url}")
        threading.Thread(target=lambda: webbrowser.open(url), daemon=True).start()
    app.run(debug=True, host="0.0.0.0", port=port)

if __name__ == "__main__":
    launch_app()